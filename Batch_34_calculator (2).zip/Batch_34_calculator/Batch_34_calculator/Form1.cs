﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;

namespace Batch_34_calculator
{
    public partial class Form1 : Form
    {
        string num;
        float prevnum;
        int flagpow = 1;
        public Form1()
        {
            InitializeComponent();
            num = "";
            prevnum = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void calculatepower(string op,string optext)
        {
            string operators = op;
            if (flagpow == 0 && operators.Contains(optext))
            {
                string[] a = num.Split('^');
                double val = Math.Pow(float.Parse(a[0]), float.Parse(a[1]));
                num = val.ToString();
                flagpow = 1;
            }
        }
        private void btndigits_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            calculatepower("+-*/",b.Text);
            num += b.Text;
            txtdisplay.Text = num;
        }


        private void btnbackspace_Click(object sender, EventArgs e)
        {
            int noofchar = num.Length;
            if (noofchar > 0)
                num = num.Remove(noofchar - 1, 1);
            else
                num = "";
            txtdisplay.Text = num;
        }
        private void btnce_Click(object sender, EventArgs e)
        {
            num = "";
            txtdisplay.Text = num;
        }
        private void btnc_Click(object sender, EventArgs e)
        {
            num = "";
            txtdisplay.Text = num;
        }



        private void btnequal_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            var res = dt.Compute(num, "");
           // MessageBox.Show(res.ToString());
            num = res.ToString();
            txtdisplay.Text = num;
        }

        private void btnplusminus_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            var res = dt.Compute(num, "");
            float val = float.Parse(res.ToString());
            val = -val;
            num = val.ToString();
            txtdisplay.Text = num;
        }

        private void btnsqroot_Click(object sender, EventArgs e)
        {
            calculatepower("","");
            DataTable dt = new DataTable();
            var res = dt.Compute(num, "");
            float val = float.Parse(res.ToString());
            val =float.Parse(Math.Sqrt(val).ToString());
            num = val.ToString();
            txtdisplay.Text = num;
        }

        private void btnpow_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            var res = dt.Compute(num, "");
            float val = float.Parse(res.ToString());
            num = val.ToString() + "^";
            txtdisplay.Text = num;
            flagpow = 0;
        }

        private void btnper_Click(object sender, EventArgs e)
        {
            string op = "+-*/";
            int i;
            for(i=num.Length-1;i>=0;i--)
            {
                if(op.Contains(num[i].ToString()))
                {
                    break;
                }
            }
            string num1 = num.Substring(0, i);
            string num2 = num.Substring(i + 1);
            DataTable dt = new DataTable();
            var res = dt.Compute(num1, "");
            float val = float.Parse(res.ToString());

            float per = val * (float.Parse(num2)) / 100;
            var res2 = dt.Compute(res.ToString() + num[i].ToString() + per.ToString(), "");
            //MessageBox.Show("val " + val.ToString() + "\n" + "per = " + per.ToString());
            //MessageBox.Show(res.ToString() + num[i].ToString() + per.ToString());
            num = res2.ToString();
            txtdisplay.Text = num;
        }
    }
}
