﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Batch34_day20
{
    public partial class Form1 : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataTable stu = GetStudentDetails();
            dataGridView1.DataSource = stu;

        }

        DataTable GetStudentDetails()
        {
            dt = new DataTable("Students");

            dc = new DataColumn("RollNumber", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("FullName", typeof(string));
            dt.Columns.Add(dc);

            dc = new DataColumn("Subject", typeof(string));
            dt.Columns.Add(dc);

            dc = new DataColumn("Fees", typeof(float));
            dt.Columns.Add(dc);

            dc = new DataColumn("DeptId", typeof(int));
            dt.Columns.Add(dc);

            dr = dt.NewRow();
            dr[0] = 111;
            dr[1] = "Anjana Naik";
            dr[2] = "Dot Net";
            dr[3] = 35000;
            dr[4] = 301;
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr[0] = 112;
            dr[1] = "Sathish S";
            dr[2] = "Python";
            dr[3] = 30000;
            dr[4] = 302;
            dt.Rows.Add(dr);


            dr = dt.NewRow();
            dr[0] = 113;
            dr[1] = "Saquib Shaikh";
            dr[2] = "Web Dev";
            dr[3] = 25000;
            dr[4] = 301;
            dt.Rows.Add(dr);

            return dt;
        }
    }
}
